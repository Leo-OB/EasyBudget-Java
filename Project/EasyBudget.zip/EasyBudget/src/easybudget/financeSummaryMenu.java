
package easybudget;

import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;


public class financeSummaryMenu {
    
    EasyBudget budgetapp;
    
    Label summaryLabel;
    
    public financeSummaryMenu(EasyBudget app) {
        this.budgetapp = app;
    }
    
    //Called every time the scene is shown
    void refresh() {
        summaryLabel.setText("");
        summaryLabel.setVisible(false);
        
        System.out.println("\n---------- Financial Summary ----------");
    }

    

    Scene build() {
        //Components
        
            Label title = new Label("Financial Summary");
            title.getStyleClass().add("title");
            
            Button btnDisplay = new Button("Display Financial Summary");
            Button btnBack = new Button("Back to main menu");
            btnBack.getStyleClass().add("secondary");
            
            summaryLabel = new Label();
            summaryLabel.setVisible(false);
            summaryLabel.setStyle("-fx-font-family: monospace;");
            summaryLabel.getStyleClass().add("summary");
            
        //Actions
        
            btnDisplay.setOnAction(e -> {
                double income   = budgetapp.database.getTotalIncome();
                double expenses = budgetapp.database.getTotalExpenses();
                double balance  = budgetapp.database.getBalance();
                
                StringBuilder text = new StringBuilder();
                
                text.append("--- Financial Summary ---\n");
                text.append(String.format("Total Income   : R%,.2f%n", income));
                text.append(String.format("Total Expenses : R%,.2f%n", expenses));
                text.append(String.format("Balance        : R%,.2f%n", balance));
                
                if (balance < 0) text.append("You are overspending...\n");
                
                System.out.print(text);
                summaryLabel.setText(text.toString());
                summaryLabel.setVisible(true);
            });
            
            btnBack.setOnAction(e -> budgetapp.showMenu());
            
        //Layout
        
            VBox layout = new VBox(15, title, btnDisplay, summaryLabel, btnBack);
            layout.setPadding(new Insets(20));

        return new Scene(layout, 700, 700);
    }
    
    
}
