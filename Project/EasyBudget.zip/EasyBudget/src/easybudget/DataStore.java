package easybudget;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class DataStore {

  
    private static final String DB_URL = "jdbc:mysql://localhost:3306/easybudget";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "";
    
    private User currentUser;

    public static class User {
        final int id;
        final String username;

        User(int id, String username) {
            this.id = id;
            this.username = username;
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }
    
    

    public boolean authenticate(String username, String password) {
        String sql = "SELECT id, username FROM Users WHERE username = ? AND password = ?";
        try (Connection conn = getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
             
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                currentUser = new User(rs.getInt("id"), rs.getString("username"));
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Authentication error: " + e.getMessage());
        }
        return false;
    }
    
    public boolean isUsernameTaken(String username) {
    String sql = "SELECT 1 FROM Users WHERE username = ?";
    try (Connection conn = getConnection(); 
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
         
        pstmt.setString(1, username);
        ResultSet rs = pstmt.executeQuery();
        return rs.next(); // Returns true if a record with this username exists
    } catch (SQLException e) {
        System.out.println("Username lookup error: " + e.getMessage());
    }
    return false;
}

    public void registerUser(String username, String password) {
        String sql = "INSERT INTO Users (username, password) VALUES (?, ?)";
        try (Connection conn = getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
             
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.executeUpdate();
            
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                currentUser = new User(rs.getInt(1), username);
            }
        } catch (SQLException e) {
            System.out.println("Registration error: " + e.getMessage());
        }
    }

    public User getCurrentUser() { 
        return currentUser; 
    }

    public void addTransaction(Transactions t) {
        String sql = "INSERT INTO Transactions (user_id, type, category, description, amount) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
             
            pstmt.setInt(1, currentUser.id);
            pstmt.setString(2, t.getType().name());
            pstmt.setString(3, t.getCategory());
            pstmt.setString(4, t.getDescription());
            pstmt.setDouble(5, t.getAmount());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Add transaction error: " + e.getMessage());
        }
    }

    public List<Transactions> getTransactions() {
        List<Transactions> list = new ArrayList<>();
        if (currentUser == null) return list;
        
        String sql = "SELECT type, category, description, amount FROM Transactions WHERE user_id = ?";
        try (Connection conn = getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
             
            pstmt.setInt(1, currentUser.id);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Transactions.Type type = Transactions.Type.valueOf(rs.getString("type"));
                Transactions t = new Transactions(
                    type, 
                    rs.getString("category"), 
                    rs.getString("description"), 
                    rs.getDouble("amount")
                );
                list.add(t);
            }
        } catch (SQLException e) {
            System.out.println("Fetch transactions error: " + e.getMessage());
        }
        return list;
    }

    public double getBalance() {
        return getTotalIncome() - getTotalExpenses();
    }

    public double getTotalIncome() {
        return getAggregateSum("INCOME");
    }

    public double getTotalExpenses() {
        return getAggregateSum("EXPENSE");
    }

    private double getAggregateSum(String type) {
        if (currentUser == null) return 0.0;
        
        String sql = "SELECT SUM(amount) FROM Transactions WHERE user_id = ? AND type = ?";
        try (Connection conn = getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
             
            pstmt.setInt(1, currentUser.id);
            pstmt.setString(2, type);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (SQLException e) {
            System.out.println("Aggregate sum error: " + e.getMessage());
        }
        return 0.0;
    }

    public Map<String, Double> totalsByCategory(Transactions.Type type) {
        Map<String, Double> map = new LinkedHashMap<>();
        if (currentUser == null) return map;
        
        String sql = "SELECT category, SUM(amount) as cat_total FROM Transactions WHERE user_id = ? AND type = ? GROUP BY category";
        try (Connection conn = getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
             
            pstmt.setInt(1, currentUser.id);
            pstmt.setString(2, type.name());
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                map.put(rs.getString("category"), rs.getDouble("cat_total"));
            }
        } catch (SQLException e) {
            System.out.println("Category totals error: " + e.getMessage());
        }
        return map;
    }
}