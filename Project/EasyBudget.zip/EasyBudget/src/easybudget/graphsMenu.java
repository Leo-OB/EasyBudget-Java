package easybudget;

import java.util.Map;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import javafx.scene.chart.PieChart;            
import javafx.scene.layout.HBox;

public class graphsMenu {
    
    EasyBudget budgetapp; 
    TextArea outputArea;
    HBox pieLayout;
    
    private static final String[] EXPENSE_CATEGORIES = {
        "Bills / Fees",
        "Health / Personal Care",
        "Housing Utilities",
        "Travel / Transport",
        "Food / Groceries",
        "Entertainment",
        "Other"
    };
    
    private static final String[] INCOME_CATEGORIES = {
        "Salary / Wages",
        "Business / Freelance",
        "Investments",
        "Gifts",
        "Other"
    };

  
    public graphsMenu(EasyBudget app) {
        this.budgetapp = app;
    }
    
    void refresh() {
        outputArea.clear();
        outputArea.setVisible(false);
        outputArea.setManaged(false);
        pieLayout.setVisible(false);
        pieLayout.setManaged(false);
        
        System.out.println("\n         Graph Menu          ");
        System.out.println("===============================");
    }

    Scene build() {   
        //Components
        Label title = new Label("Graphs");
        title.getStyleClass().add("title");
        
        Button btnDisplay = new Button("Display Graph(s)");
        Button btnBack = new Button("Back to main menu");
        btnBack.getStyleClass().add("secondary");

        outputArea = new TextArea();
        outputArea.setEditable(false);
        outputArea.setVisible(false);
        outputArea.setStyle("-fx-font-family: monospace;");
            
        //Pie components    
        PieChart expensePie = new PieChart();
        PieChart incomePie = new PieChart();
        expensePie.setTitle("Expenses");
        incomePie.setTitle("Income");

        pieLayout = new HBox(10, expensePie, incomePie);
        expensePie.setPrefSize(450, 350);
        incomePie.setPrefSize(450, 350);
        pieLayout.setVisible(false);
        pieLayout.setManaged(false);
            
        //Actions
        btnDisplay.setOnAction(e -> {
            
            StringBuilder text = new StringBuilder();
            
            //displays expense graph, total with heading "Expense categories"
            text.append(getGraphs(
                Transactions.Type.EXPENSE,
                budgetapp.database.getTotalExpenses(),
                "Expense Categories")); 

            text.append("\n");
            
            //displays income graph, total with heading "Income categories"
            text.append(getGraphs(
                Transactions.Type.INCOME,
                budgetapp.database.getTotalIncome(),
                "Income Categories"));

            System.out.print(text);
            outputArea.setText(text.toString());
            outputArea.setVisible(true);
            outputArea.setManaged(true);

            //piechart setting
            expensePie.getData().setAll(createPieChart(Transactions.Type.EXPENSE).getData());
            incomePie.getData().setAll(createPieChart(Transactions.Type.INCOME).getData());
            pieLayout.setVisible(true);
            pieLayout.setManaged(true);
            });
        
        btnBack.setOnAction(e -> {
            //Hide piecharts
            pieLayout.setVisible(false);
            pieLayout.setManaged(false);
            
            budgetapp.showMenu();
        });
            
        //Layout
        VBox layout = new VBox(15, title, btnDisplay, pieLayout, outputArea, btnBack);
        layout.setPadding(new Insets(20));
        VBox.setVgrow(outputArea, Priority.ALWAYS);

        return new Scene(layout, 1000, 700);
    }

    //creates text/console based graphs for display in the GUI
    private String getGraphs(Transactions.Type type, double total, String heading) {

        StringBuilder text = new StringBuilder();
        
        Map<String, Double> categories = budgetapp.database.totalsByCategory(type); //gets total for each catergory      
        String[] allCategories;
        
        if (type == Transactions.Type.EXPENSE) {          //selects either expense or income catergory name list from arrays
            allCategories = EXPENSE_CATEGORIES;
        } else {
            allCategories = INCOME_CATEGORIES;
        }

        text.append("--- " + heading + " ---\n");
        
        for (int i = 0; i < allCategories.length; i++) { //loops through all categories
            String category = allCategories[i];          //gets current category name
            double amount = categories.getOrDefault(category, 0.0); //gets amount or returns 0 if no amount
            double percentage = 0;

            if (total > 0) {                             //calcs % of total
                percentage = amount * 100.0 / total;
            }

            int bars = (int) Math.round(percentage / 2); // (percentage/y) , each bar "=" is represented by y%
            text.append(String.format("%-25s", category + ":"));
            for (int j = 0; j < bars; j++) {
                text.append("=");
            }

            text.append(String.format(" %.1f%%%n", percentage));
        }
        text.append(String.format("Total: R%,.2f%n", total));
        
        return text.toString();
    
    } 

    //creates JavaFX piecharts using category totals from the database
    private PieChart createPieChart(Transactions.Type type) {
        
        Map<String, Double> categories = budgetapp.database.totalsByCategory(type);

        PieChart chart = new PieChart();

        for (Map.Entry<String, Double> entry : categories.entrySet()) {       
            if (entry.getValue() > 0) {
                chart.getData().add(new PieChart.Data(entry.getKey(),entry.getValue()));
            }
        }       
        chart.setLegendVisible(true);
        chart.setAnimated(true);

        return chart;
    }
}