
package easybudget;

import java.util.Map;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class categoryMenu {
    
    EasyBudget budgetapp;
    
    TextArea outputArea;
    
    public categoryMenu(EasyBudget app) {
        this.budgetapp = app;
    }
    
    //Called every time the scene is shown
    void refresh() {
        outputArea.clear();
        outputArea.setVisible(false);
        
        System.out.println("\n---------- Category Menu ----------");
    }

   

    Scene build() {
        
        //Components
            Label title = new Label("Categories");
            title.getStyleClass().add("title");
            
            Button btnDisplay = new Button("Display Categories");
            Button btnBack = new Button("Back to main menu");
            btnBack.getStyleClass().add("secondary");
            
            outputArea = new TextArea();
            outputArea.setEditable(false);
            outputArea.setVisible(false);
            outputArea.setStyle("-fx-font-family: monospace;");
        
        //Actions
        
            btnDisplay.setOnAction(e -> {
                StringBuilder text = new StringBuilder();
                
                text.append(getCategories(Transactions.Type.INCOME, "\n--- Income Categories ---"));
                text.append(getCategories(Transactions.Type.EXPENSE, "\n--- Expense Categories ---"));
                
                System.out.print(text);
                outputArea.setText(text.toString());
                outputArea.setVisible(true);
            });
        
            btnBack.setOnAction(e -> budgetapp.showMenu());
            
        //Layout
        
            VBox layout = new VBox(15, title, btnDisplay, outputArea, btnBack);
            layout.setPadding(new Insets(20));
            VBox.setVgrow(outputArea, Priority.ALWAYS);

        return new Scene(layout, 700, 700);
    }
    
    //Same as printCategories() in the console version, but returns the text instead of printing it
    private String getCategories(Transactions.Type type, String header) {
        
        StringBuilder text = new StringBuilder();
        
        text.append(header).append("\n");
        
        Map<String, Double> totals = budgetapp.database.totalsByCategory(type);
        
        if (totals.isEmpty()) {
            text.append("  No entries recorded.\n");
            return text.toString();
        }
        
        for (Map.Entry<String, Double> e : totals.entrySet()) {
            
            text.append(String.format("  %-22s R%,.2f%n", e.getKey(), e.getValue()));
            
            // drill-down: individual transactions in this category
            for (Transactions t : budgetapp.database.getTransactions()) {
                if (t.getType() == type && t.getCategory().equals(e.getKey())) {
                    text.append(String.format("      - %-25s R%,.2f%n",
                            t.getDescription(), t.getAmount()));
                }
            }
        }
        
        return text.toString();
    }
    
}
