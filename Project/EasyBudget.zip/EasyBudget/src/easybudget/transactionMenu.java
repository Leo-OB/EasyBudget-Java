
package easybudget;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class transactionMenu {

    EasyBudget budgetapp;
    
    TextArea outputArea;
    
    public transactionMenu(EasyBudget app) {
        this.budgetapp = app;
    }
    
    //Called every time the scene is shown
    void refresh() {
        outputArea.clear();
        outputArea.setVisible(false);
        
        System.out.println("\n---------- Transaction Menu ----------");
    }

    Scene build() {
       //Components
        
            Label title = new Label("Transactions");
            title.getStyleClass().add("title");
            
            Button btnDisplay = new Button("Display Transactions");
            Button btnBack = new Button("Back to main menu");
            btnBack.getStyleClass().add("secondary");
            
            outputArea = new TextArea();
            outputArea.setEditable(false);
            outputArea.setVisible(false);
            outputArea.setStyle("-fx-font-family: monospace;");
            
        //Actions
        
            btnDisplay.setOnAction(e -> {
                StringBuilder text = new StringBuilder();
                
                text.append("--- All Transactions ---\n");
                if (budgetapp.database.getTransactions().isEmpty()) {
                    text.append("No transactions recorded.\n");
                    
                } else {
                    for (Transactions t : budgetapp.database.getTransactions())
                        text.append(t).append("\n");
                }
                
                System.out.print(text);
                outputArea.setText(text.toString());
                outputArea.setVisible(true);
            });
        
            btnBack.setOnAction(e -> budgetapp.showMenu());
            
        //Layout
        
            VBox layout = new VBox(15, title, btnDisplay, outputArea, btnBack);
            layout.setPadding(new Insets(20));
            VBox.setVgrow(outputArea, Priority.ALWAYS);

            
        return new Scene(layout, 700, 700); 
    }
    
}
