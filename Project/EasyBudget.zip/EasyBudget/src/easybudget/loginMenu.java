
package easybudget;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

public class loginMenu {

    EasyBudget budgetapp;

    TextField usernameField;
    PasswordField passwordField;
    PasswordField confirmField;
    Label feedbackField;

    public loginMenu(EasyBudget app) {
        this.budgetapp = app;
    }

    //Called every time the scene is shown
    void refresh() {
        usernameField.clear();
        passwordField.clear();
        confirmField.clear();
        feedbackField.setVisible(false);

        System.out.println("Hi welcome to EasyBudget");
        System.out.println("Choose an option to login/register:");
        System.out.println("(1) Login\n(2) Register\n");
    }

    Scene build() {
        
        

        //Components

            Label title             = new Label("Hi welcome to EasyBudget");
            title.getStyleClass().add("title");
            
            
            usernameField           = new TextField();
            passwordField           = new PasswordField();
            confirmField            = new PasswordField();
            feedbackField           = new Label();
            feedbackField.getStyleClass().add("feedback");
            
            usernameField.setPromptText("Enter username");
            passwordField.setPromptText("Enter password");
            confirmField.setPromptText("Confirm password (register only)");
            feedbackField.setVisible(false);

            Button btnLogin         = new Button("Login");
            Button btnRegister      = new Button("Register");

        //Actions

            btnLogin.setOnAction(e -> {
                System.out.println("----------Login Now----------");

                if (budgetapp.database.authenticate(usernameField.getText(), passwordField.getText())) {
                    System.out.println("Login successful...\n");
                    budgetapp.showMenu();

                } else {
                    System.out.println("Invalid credentials. Try again.\n");
                    feedbackField.setText("Invalid credentials. Try again.");
                    feedbackField.setVisible(true);
                }
            });

btnRegister.setOnAction(e -> {
    System.out.println("----------Register Now----------");
    
    String username = usernameField.getText().trim();
    String password = passwordField.getText();
    String confirm  = confirmField.getText();

    if (username.isEmpty()) {
        System.out.println("Username cannot be empty.");
        feedbackField.setText("Username cannot be empty.");

    } else if (!password.equals(confirm)) {
        System.out.println("Passwords do not match, try again.");
        feedbackField.setText("Passwords do not match, try again.");

    } else if (budgetapp.database.isUsernameTaken(username)) {
        String msg = "Username already exists. Please choose a different one.";
        System.out.println(msg + "\n");
        feedbackField.setText(msg);

    } else {
        budgetapp.database.registerUser(username, password);
        System.out.println("Registration successful, you are now logged in.\n");
        budgetapp.showMenu();
    }
    feedbackField.setVisible(true);
});

        //Layout

            VBox layout = new VBox(10, title, usernameField, passwordField, confirmField, btnLogin, btnRegister, feedbackField);
            layout.setPadding(new Insets(20));
            return new Scene(layout, 700, 500);
    }

}
