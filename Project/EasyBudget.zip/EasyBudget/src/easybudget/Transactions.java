package easybudget;

public class Transactions {
    
    public enum Type {
        INCOME, EXPENSE
    }
    
    private final Type type;
    private final String category;
    private final String description;
    private final double amount;
    
    public Transactions(Type type, String category, String description, double amount) {
        this.type = type;
        this.category = category;
        this.description = description;
        this.amount = amount;
    }
    
    public Type getType() { 
        return type; 
    }
    
    public String getCategory() { 
        return category; 
    }
    
    public String getDescription() { 
        return description; 
    }
    
    public double getAmount() { 
        return amount; 
    }
    
    @Override
    public String toString() {
        return String.format("%-10s | %-22s | %-20s | R%,.2f", type, category, description, amount);
    }
}