 
package easybudget;

import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

public class expenseMenu {

    EasyBudget budgetapp;

    private static final String[] CATEGORIES = { "Bills / Fees", "Health / Personal Care", "Housing Utilities", "Travel / Transport", "Food / Groceries", "Entertainment", "Other"};

    TextField amountField;
    TextField typeField;
    ComboBox<String> categoryBox;
    Label feedbackField;

    public expenseMenu(EasyBudget app) {
        this.budgetapp = app;
    }

    //Called every time the scene is shown
    void refresh() {
        amountField.clear();
        typeField.clear();
        categoryBox.setValue(null);
        feedbackField.setVisible(false);

        System.out.println("\n---------- Expenses Menu ----------");
    }

    Scene build() {

        //Components

            Label title = new Label("Add Expense");
            title.getStyleClass().add("title");
            
            amountField   = new TextField();
            typeField     = new TextField();
            categoryBox   = new ComboBox<>();
            feedbackField = new Label();
            feedbackField.getStyleClass().add("feedback");

            amountField.setPromptText("Add amount");
            typeField.setPromptText("Add type");
            categoryBox.getItems().addAll(CATEGORIES);
            categoryBox.setPromptText("Select a category");
            feedbackField.setVisible(false);

            Button btnAdd           = new Button("Add Expense");
            Button btnCancel        = new Button("Cancel");
            Button btnBack          = new Button("Back to main menu");
            btnCancel.getStyleClass().add("secondary");         // ADDED
            btnBack.getStyleClass().add("secondary");

        //Actions

            btnAdd.setOnAction(e -> {
                if (amountField.getText().isEmpty() || typeField.getText().isEmpty()) {
                    feedbackField.setText("Please fill in amount and description.");

                } else if (budgetapp.amountError(amountField.getText()) != null) {

                    String error = budgetapp.amountError(amountField.getText());
                    System.out.println(error);
                    feedbackField.setText(error);

                } else if (categoryBox.getValue() == null) {

                    System.out.println("Invalid category — entry not saved.");
                    feedbackField.setText("Invalid category — entry not saved.");

                } else {

                    double amount = budgetapp.parseAmount(amountField.getText());

                    budgetapp.database.addTransaction(new Transactions(Transactions.Type.EXPENSE, categoryBox.getValue(), typeField.getText(), amount));

                    String message = String.format("Expense added! New balance: R%,.2f", budgetapp.database.getBalance());
                    feedbackField.setText(message);
                    System.out.println(message + "\n");
                    amountField.clear();
                    typeField.clear();
                    categoryBox.setValue(null);
                }
                feedbackField.setVisible(true);
            });

            btnCancel.setOnAction(e -> {
                System.out.println("Cancelling entry...\n");
                amountField.clear();
                typeField.clear();
                categoryBox.setValue(null);
                feedbackField.setText("Cancelling entry...");
                feedbackField.setVisible(true);
            });

            btnBack.setOnAction(e -> budgetapp.showMenu());

        //Layout

            VBox layout = new VBox(10, title, amountField, typeField, categoryBox, btnAdd, btnCancel, feedbackField, btnBack);
            layout.setPadding(new Insets(20));


        return new Scene(layout, 700, 700);
    }

}
