
package easybudget;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class mainMenu {

    EasyBudget budgetapp;

    Label title1;

    public mainMenu(EasyBudget app) {
        this.budgetapp = app;

    }

    //Called every time the scene is shown
    void refresh() {
        title1.setText(String.format("Balance: R%,.2f", budgetapp.database.getBalance()));

        System.out.println("\n---------- EasyBudget ----------");
        System.out.println("Welcome to your efficient financial tracker!");
        System.out.printf("\nCurrent balance: R%,.2f%n", budgetapp.database.getBalance());
    }

    Scene build() {
        
        //Components

            Label title             = new Label("Welcome to Main Menu!");
            title.getStyleClass().add("title");
            
            title1                  = new Label("Balance: ");
            title1.getStyleClass().add("balance");
            

            Button btnIncome        = new Button("Add income");
            Button btnExpense       = new Button("Add Expenses");
            Button btnTransactions  = new Button("Transactions");
            Button btnSummary       = new Button("Financial Summary");
            Button btnCategories    = new Button("Categories");
            Button btnGraphs        = new Button("Graphs");
            Button btnExit          = new Button("Exit");
            btnExit.getStyleClass().add("secondary");


        //Actions

            btnIncome       .setOnAction(e -> budgetapp.showIncome());
            btnExpense      .setOnAction(e -> budgetapp.showExpense());
            btnTransactions .setOnAction(e -> budgetapp.showTransactions());
            btnSummary      .setOnAction(e -> budgetapp.showSummary());
            btnCategories   .setOnAction(e -> budgetapp.showCategories());
            btnGraphs       .setOnAction(e -> budgetapp.showGraphs());
            btnExit         .setOnAction(e -> {
                System.out.println("Goodbye!");
                System.exit(0);
            });


        //Layouts

            VBox layout = new VBox(30, title, title1, btnIncome, btnExpense, btnTransactions, btnSummary, btnCategories, btnGraphs, btnExit);
            layout.setPadding(new Insets(20)); //moves diagonally down to the right the higher the inset
//          layout.setAlignment(Pos.CENTER);
            layout.setFillWidth(false);
            return new Scene(layout, 700, 700);
    }



}
