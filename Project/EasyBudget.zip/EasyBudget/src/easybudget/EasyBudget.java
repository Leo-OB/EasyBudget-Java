package easybudget;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class EasyBudget extends Application {

    Stage window;
    Scene loginScene, menuScene, incomeScene, expenseScene, transactionScene, summaryScene, categoryScene, graphsScene;

    DataStore database = new DataStore();

    loginMenu           loginPage;
    mainMenu            mainPage;
    incomeMenu          incomePage;
    expenseMenu         expensePage;
    transactionMenu     transactionPage;
    financeSummaryMenu  summaryPage;
    categoryMenu        categoryPage;
    graphsMenu          graphsPage;

    int sceneWidth = 700;
    int sceneHeight = 700;

    public static void main(String[] args) {
        launch(args);
    }


    @Override
    public void start(Stage primaryStage) {

        window              = primaryStage;

        loginPage           = new loginMenu(this);
        mainPage            = new mainMenu(this);
        incomePage          = new incomeMenu(this);
        expensePage         = new expenseMenu(this);
        transactionPage     = new transactionMenu(this);
        summaryPage         = new financeSummaryMenu(this);
        categoryPage        = new categoryMenu(this);
        graphsPage          = new graphsMenu(this);

        loginScene          = loginPage.build();
        menuScene           = mainPage.build();
        incomeScene         = incomePage.build();
        expenseScene        = expensePage.build();
        transactionScene    = transactionPage.build();
        summaryScene        = summaryPage.build();
        categoryScene       = categoryPage.build();
        graphsScene         = graphsPage.build();

     for (Scene s : new Scene[]{loginScene, menuScene, incomeScene, expenseScene, transactionScene, summaryScene, categoryScene, graphsScene}) {
    s.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
    }   

        showLogin();
        window.setTitle("Easy Budget");
        window.show();
    }

    public void showLogin(){
        loginPage.refresh();
        window.setScene(loginScene);
    }

    public void showMenu(){
        mainPage.refresh();
        window.setScene(menuScene);
    }

    public void showIncome(){
        incomePage.refresh();
        window.setScene(incomeScene);
    }

    public void showExpense(){
        expensePage.refresh();
        window.setScene(expenseScene);
    }

    public void showTransactions(){
        transactionPage.refresh();
        window.setScene(transactionScene);
    }


    public void showSummary(){
        summaryPage.refresh();
        window.setScene(summaryScene);
    }

    public void showCategories(){
        categoryPage.refresh();
        window.setScene(categoryScene);
    }

    public void showGraphs(){
        graphsPage.refresh();
        window.setScene(graphsScene);
    }


    //Replaces readAmount() from the console version. Returns null if the text is fine, otherwise the error message
    public String amountError(String text) {
        if (text == null) {
        return "Only numerical values can be entered in the amount textfield.";
    }
        
        String s = text.trim().replace(",", "");
        
        if (!s.matches("^\\d+(\\.\\d+)?$")) {
        return "Only numerical values can be entered in the amount textfield.";
    }
        
        
        try {
            double d = Double.parseDouble(s);
       
            if (d < 0) {
                return "Amount cannot be negative.";
            }
            return null;
        } catch (NumberFormatException e) {
            return "Please enter a valid amount.";
        }
    }

    //Only call after amountError() returned null
    public double parseAmount(String text) {
        return Double.parseDouble(text.trim().replace(",", ""));
    }


}
